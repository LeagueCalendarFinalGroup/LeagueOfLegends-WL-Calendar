module RiotApiClient
  VERSION = "0.1.0"
end
