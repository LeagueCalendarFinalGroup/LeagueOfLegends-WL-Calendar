require "riot_api_client/version"
require "riot_api_client/client"
require "riot_api_client/errors"

module RiotApiClient
  class Error < StandardError; end
   
    puts "Enter summoner ID: "
    summonerName=gets
    puts summonerName

    
end

